AYAZ TRADE — PROFESYONEL TOP10 CANLI TARAMA v2

GitHub Pages repo içine sadece index.html yükle.

Link:
https://mrayaz35-jpg.github.io/ayaz-trade-mobile/?v=pdf-profesyonel-top10-v2

Özellikler:
- Binance canlı veri
- En az 150 USDT coin
- 15m / 30m / 1h / 2h / 4h tarama
- LONG + SHORT adayları
- Güven sırasına göre Top 10
- Adaya dokununca backtest
- USDT yanında TL fiyat
- Kaldıraç / pozisyon / marjin
- Destek, direnç, trend, BOS/CHOCH, FVG, likidite sweep, mum, hacim, RSI, MACD, ADX, ATR risk
